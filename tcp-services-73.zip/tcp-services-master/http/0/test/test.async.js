

let works=socket.setHeader("Content-Type", "text/plain")
//console.log("works",works)
//await socket.writeText("hello world at " +url.toString());
socket.close("heelo");

/*export default async function(socket,url: URL,get: string){
    socket.setHeader("content-type", "text/plain")
    await socket.writeText("hello world at" +url.toString());
    socket.close();
}*/